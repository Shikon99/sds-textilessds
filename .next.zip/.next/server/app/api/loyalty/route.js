var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/loyalty/route.js")
R.c("server/chunks/[root-of-the-server]__0z6jc0k._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_loyalty_route_actions_0n22r4k.js")
R.m(43844)
module.exports=R.m(43844).exports
