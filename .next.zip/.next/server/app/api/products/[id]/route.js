var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ydnh6j._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_route_actions_0gjxx5m.js")
R.m(11518)
module.exports=R.m(11518).exports
