var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__02a9_8k._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_0qlulka.js")
R.m(86577)
module.exports=R.m(86577).exports
