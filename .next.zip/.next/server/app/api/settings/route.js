var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__13wtazr._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_0sa6rdk.js")
R.m(83579)
module.exports=R.m(83579).exports
