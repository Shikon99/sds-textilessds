var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/route.js")
R.c("server/chunks/[root-of-the-server]__0xkkc-7._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_products_route_actions_0_t2yuk.js")
R.m(85145)
module.exports=R.m(85145).exports
