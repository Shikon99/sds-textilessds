var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__06l6~q~._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_products_[id]_route_actions_0hnezxh.js")
R.m(5073)
module.exports=R.m(5073).exports
