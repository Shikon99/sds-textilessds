var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/route.js")
R.c("server/chunks/[root-of-the-server]__0dz_vrp._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_orders_route_actions_0ntsj4..js")
R.m(54009)
module.exports=R.m(54009).exports
