var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0odypca._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_orders_[id]_route_actions_0s2e1ru.js")
R.m(13452)
module.exports=R.m(13452).exports
