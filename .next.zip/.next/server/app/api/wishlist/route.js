var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/wishlist/route.js")
R.c("server/chunks/[root-of-the-server]__02a58lq._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_wishlist_route_actions_0l--8p2.js")
R.m(5910)
module.exports=R.m(5910).exports
