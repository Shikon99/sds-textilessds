var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/wishlist/get-or-create/route.js")
R.c("server/chunks/[root-of-the-server]__13d0tvl._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_wishlist_get-or-create_route_actions_0ztd4s5.js")
R.m(80909)
module.exports=R.m(80909).exports
