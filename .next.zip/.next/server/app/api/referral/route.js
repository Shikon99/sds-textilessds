var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/referral/route.js")
R.c("server/chunks/[root-of-the-server]__014szr1._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_referral_route_actions_079uai_.js")
R.m(24174)
module.exports=R.m(24174).exports
