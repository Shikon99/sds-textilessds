var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0d3ddcl._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_reviews_route_actions_0jw7amc.js")
R.m(68163)
module.exports=R.m(68163).exports
