var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__0gxixbd._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_search_route_actions_0bffyy~.js")
R.m(51604)
module.exports=R.m(51604).exports
