var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/flash-sales/route.js")
R.c("server/chunks/[root-of-the-server]__0i4ssvy._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_flash-sales_route_actions_0~7_hbu.js")
R.m(91648)
module.exports=R.m(91648).exports
