var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/sign-up/route.js")
R.c("server/chunks/[root-of-the-server]__0r4dtp0._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_sign-up_route_actions_093e9~_.js")
R.m(49980)
module.exports=R.m(49980).exports
