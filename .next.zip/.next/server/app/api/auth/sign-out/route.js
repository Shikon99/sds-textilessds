var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/sign-out/route.js")
R.c("server/chunks/[root-of-the-server]__0scqmf3._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_sign-out_route_actions_0~4assa.js")
R.m(10402)
module.exports=R.m(10402).exports
