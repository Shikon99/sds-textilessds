var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__0-gb6f-._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_refresh_route_actions_10er5ms.js")
R.m(43712)
module.exports=R.m(43712).exports
