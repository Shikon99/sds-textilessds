var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__0.ebprl._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/lib_auth_jwt_ts_010fb.r._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_admin_login_route_actions_0gm83xp.js")
R.m(82256)
module.exports=R.m(82256).exports
