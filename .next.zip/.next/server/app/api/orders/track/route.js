var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/track/route.js")
R.c("server/chunks/[root-of-the-server]__0aw_7dy._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_track_route_actions_0tee0fv.js")
R.m(13300)
module.exports=R.m(13300).exports
