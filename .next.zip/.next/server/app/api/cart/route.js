var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cart/route.js")
R.c("server/chunks/[root-of-the-server]__0j5_re9._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_cart_route_actions_0hcv~-8.js")
R.m(5097)
module.exports=R.m(5097).exports
