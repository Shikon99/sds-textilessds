var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cart/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__068c4ap._.js")
R.c("server/chunks/node_modules_next_03e_drb._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_cart_[id]_route_actions_08umjuo.js")
R.m(98056)
module.exports=R.m(98056).exports
