var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cart/get-or-create/route.js")
R.c("server/chunks/[root-of-the-server]__0jiwjys._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_cart_get-or-create_route_actions_0sbd4ho.js")
R.m(90746)
module.exports=R.m(90746).exports
