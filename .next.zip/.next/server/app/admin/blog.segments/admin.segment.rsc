1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0iwz~d34oj_si.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[81830,["/_next/static/chunks/0iwz~d34oj_si.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0bfza-mn3b4y9.js","/_next/static/chunks/0jtflcix94yzp.js"],"default"]
4:I[37457,["/_next/static/chunks/0iwz~d34oj_si.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
5:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$3","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/0bfza-mn3b4y9.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0jtflcix94yzp.js","async":true}]],"template":["$","$L4",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"St-dioYBv7gG3vp2glVVo"}
