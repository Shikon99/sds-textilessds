module.exports=[82234,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_wishlist_get-or-create_route_actions_0ztd4s5.js.map