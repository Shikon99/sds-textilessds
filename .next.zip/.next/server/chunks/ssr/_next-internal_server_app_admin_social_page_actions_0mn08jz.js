module.exports=[45865,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_social_page_actions_0mn08jz.js.map